# Node

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**cluster** | [**Installer\Model\ClusterInNodeList**](ClusterInNodeList.md) |  | [optional] 
**ip** | **string** |  | [optional] 
**state** | **string** |  | [optional] 
**storageMib** | [**Installer\Model\TotalUsed**](TotalUsed.md) |  | [optional] 
**ramMib** | [**Installer\Model\TotalUsed**](TotalUsed.md) |  | [optional] 
**cpuNumber** | **int** |  | [optional] 
**comment** | **string** |  | [optional] 
**interfaces** | **array** |  | [optional] 
**overselling** | **float** |  | [optional] 
**hddOverselling** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


