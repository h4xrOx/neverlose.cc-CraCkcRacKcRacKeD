# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**email** | **string** |  | [optional] 
**fullName** | **string** |  | [optional] 
**hostCount** | **int** |  | [optional] 
**state** | **string** |  | [optional] 
**role** | **array** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


