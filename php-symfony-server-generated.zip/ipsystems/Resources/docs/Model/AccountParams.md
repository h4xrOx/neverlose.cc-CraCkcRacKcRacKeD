# AccountParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** |  | 
**fullName** | **string** |  | [optional] 
**password** | **string** |  | 
**phoneNumber** | **string** |  | [optional] 
**role** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


