# SmtpParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **string** |  | 
**port** | **int** |  | 
**login** | **string** |  | [optional] 
**password** | **string** |  | [optional] 
**useSsl** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


