# NodeScriptParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**script** | **string** |  | [optional] 
**description** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**priority** | **int** |  | [optional] 
**autorun** | **float** |  | [optional] 
**account** | **array** |  | [optional] 
**updatedAt** | **array** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


