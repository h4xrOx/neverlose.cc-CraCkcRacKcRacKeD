# HostImage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**account** | **string** |  | [optional] 
**forAll** | **bool** |  | [optional] 
**type** | **string** |  | [optional] 
**comment** | **string** |  | [optional] 
**nodes** | [**Installer\Model\NodeInImage**](NodeInImage.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


