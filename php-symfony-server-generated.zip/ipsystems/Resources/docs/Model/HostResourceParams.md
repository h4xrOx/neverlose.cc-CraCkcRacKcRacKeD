# HostResourceParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpuNumber** | **int** |  | [optional] 
**ramMib** | **int** |  | [optional] 
**netBandwidthMbitps** | **int** |  | [optional] 
**defer** | **array** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


