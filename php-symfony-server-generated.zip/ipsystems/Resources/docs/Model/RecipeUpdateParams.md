# RecipeUpdateParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**tags** | **string** |  | [optional] 
**description** | **string** |  | [optional] 
**script** | **string** |  | [optional] 
**autoupdate** | **bool** |  | [optional] 
**state** | **string** |  | [optional] 
**fromRepository** | **bool** |  | [optional] 
**forAll** | **bool** |  | [optional] 
**account** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


