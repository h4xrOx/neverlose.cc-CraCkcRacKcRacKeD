# OS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**clusters** | [**Installer\Model\ClusterInOS**](ClusterInOS.md) |  | [optional] 
**repository** | **string** |  | [optional] 
**updatedAt** | **string** |  | [optional] 
**tags** | **string** |  | [optional] 
**state** | **string** |  | [optional] 
**adminonly** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


