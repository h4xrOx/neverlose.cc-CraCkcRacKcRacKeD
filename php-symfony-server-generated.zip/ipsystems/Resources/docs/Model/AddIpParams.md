# AddIpParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ipAddr** | **string** |  | [optional] 
**ipv6Pool** | **float** |  | [optional] 
**ipv6Enabled** | **bool** |  | [optional] 
**ipv4Pool** | **float** |  | [optional] 
**ipv4Number** | **float** |  | [optional] 
**interfaces** | **array** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


