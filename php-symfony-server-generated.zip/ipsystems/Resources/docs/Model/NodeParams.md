# NodeParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster** | **int** |  | 
**name** | **string** |  | [default to 'node1']
**ip** | **string** |  | [default to '1.1.1.123']
**sshPort** | **int** |  | 
**hostMax** | **int** |  | 
**password** | **string** |  | [default to 'password']
**comment** | **string** |  | [optional] [default to 'comment']
**hetznerIp** | **string** |  | [optional] 
**interfaces** | **array** |  | [optional] 
**overselling** | **float** |  | [optional] 
**hddOverselling** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


