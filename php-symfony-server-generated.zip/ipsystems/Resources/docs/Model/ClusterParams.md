# ClusterParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**virtualizationType** | **string** |  | [default to 'dummy']
**name** | **string** |  | [default to 'cl1']
**comment** | **string** |  | [optional] [default to '']
**isoEnabled** | **bool** |  | [optional] 
**timeZone** | **string** |  | [optional] [default to 'UTC']
**interfaces** | **array** |  | [optional] 
**os** | **int** |  | [optional] 
**storage** | **array** |  | 
**datacenterType** | **string** |  | [optional] [default to 'common']
**osStoragePath** | **string** |  | [optional] [default to '/share']
**imageStoragePath** | **string** |  | [optional] [default to '/images']
**netBandwidthMbitps** | **int** |  | [optional] 
**overselling** | **float** |  | [optional] 
**hddOverselling** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


