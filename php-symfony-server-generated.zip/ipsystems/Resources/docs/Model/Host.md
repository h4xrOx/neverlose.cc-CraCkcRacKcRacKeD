# Host

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**ip4** | **array** |  | [optional] 
**interfaces** | **array** |  | [optional] 
**node** | **array** |  | [optional] 
**cluster** | **array** |  | [optional] 
**state** | **string** |  | [optional] 
**account** | **int** |  | [optional] 
**comment** | **string** |  | [optional] 
**disk** | **array** |  | [optional] 
**cpuNumber** | **int** |  | [optional] 
**cpuNumberNew** | **int** |  | [optional] 
**ramMib** | **int** |  | [optional] 
**ramMibNew** | **int** |  | [optional] 
**netBandwidthMbitps** | **int** |  | [optional] 
**netBandwidthMbitpsChanged** | **bool** |  | [optional] 
**tags** | **string** |  | [optional] 
**osName** | **string** |  | [optional] 
**osGroup** | **string** |  | [optional] 
**uptime** | **int** |  | [optional] 
**rescueMode** | **bool** |  | [optional] 
**isoMounted** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


