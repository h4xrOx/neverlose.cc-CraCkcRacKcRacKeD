# Cluster

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpuNumber** | [**Installer\Model\TotalUsed**](TotalUsed.md) |  | [optional] 
**hostCount** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**comment** | **string** |  | [optional] 
**ramMib** | [**Installer\Model\TotalUsed**](TotalUsed.md) |  | [optional] 
**storageMib** | [**Installer\Model\TotalUsed**](TotalUsed.md) |  | [optional] 
**timeZone** | **string** |  | [optional] 
**state** | **string** |  | [optional] 
**dataCenter** | **string** |  | [optional] 
**nodeCount** | **int** |  | [optional] 
**id** | **int** |  | [optional] 
**netBandwidthMbitps** | **int** |  | [optional] 
**overselling** | **float** |  | [optional] 
**hddOverselling** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


