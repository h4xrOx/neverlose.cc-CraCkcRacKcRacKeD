# NodeFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**node** | **int** |  | [optional] 
**path** | **string** |  | [optional] 
**sizeMib** | **int** |  | [optional] 
**type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


