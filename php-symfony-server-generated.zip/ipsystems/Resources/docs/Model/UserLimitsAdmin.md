# UserLimitsAdmin

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostCount** | **int** |  | [optional] 
**imageCount** | **int** |  | [optional] 
**imageCountTotal** | **int** |  | [optional] 
**cpuNumber** | **int** |  | [optional] 
**cpuNumberTotal** | **int** |  | [optional] 
**ramMib** | **int** |  | [optional] 
**ramMibTotal** | **int** |  | [optional] 
**hddMib** | **int** |  | [optional] 
**hddMibTotal** | **int** |  | [optional] 
**ipv4Number** | **int** |  | [optional] 
**ipv4NumberTotal** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


