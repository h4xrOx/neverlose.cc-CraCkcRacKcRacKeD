# NodeUpdateParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostCreationBlocked** | **bool** |  | [optional] 
**openVswitch** | **bool** |  | [optional] 
**comment** | **string** |  | [optional] 
**name** | **string** |  | [optional] 
**overselling** | **float** |  | [optional] 
**hddOverselling** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


