# HostParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**cluster** | **int** |  | [optional] 
**node** | **int** |  | [optional] 
**account** | **int** |  | [optional] 
**domain** | **string** |  | [optional] 
**preset** | **float** |  | [optional] 
**os** | **int** |  | [optional] 
**image** | **int** |  | [optional] 
**recipe** | **int** |  | [optional] 
**password** | **string** |  | [optional] 
**comment** | **string** |  | [optional] 
**ramMib** | **int** |  | [optional] 
**hddMib** | **int** |  | [optional] 
**cpuNumber** | **int** |  | [optional] 
**netBandwidthMbitps** | **int** |  | [optional] 
**ipAddr** | **string** |  | [optional] 
**ipv6Pool** | **int** |  | [optional] 
**ipv6Enabled** | **bool** |  | [optional] 
**ipv4Pool** | **int** |  | [optional] 
**ipv4Number** | **int** |  | [optional] 
**cpuMode** | **string** |  | [optional] 
**macAddress** | **string** |  | [optional] 
**antiSpoofing** | **bool** |  | [optional] 
**usedTime** | **string** |  | [optional] 
**interfaces** | **array** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


