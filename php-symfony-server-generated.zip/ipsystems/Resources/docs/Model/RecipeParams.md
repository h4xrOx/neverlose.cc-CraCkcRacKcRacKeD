# RecipeParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [default to 'helloworld']
**tags** | **string** |  | 
**description** | **string** |  | [default to 'helloworld']
**script** | **string** |  | [default to 'echo "Hello world" > /root/greeting']
**forAll** | **bool** |  | [optional] 
**account** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


