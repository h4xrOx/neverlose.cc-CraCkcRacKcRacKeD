# LicenseData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostLimit** | **int** |  | [optional] 
**hostLimitExceeded** | **bool** |  | [optional] 
**license** | **array** |  | [optional] 
**nodeLimit** | **int** |  | [optional] 
**nodeLimitExceeded** | **bool** |  | [optional] 
**lastNotify** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


