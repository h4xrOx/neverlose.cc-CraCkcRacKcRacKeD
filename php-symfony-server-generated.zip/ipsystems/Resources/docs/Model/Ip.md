# Ip

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**ipAddr** | **string** |  | [optional] 
**domain** | **string** |  | [optional] 
**gateway** | **string** |  | [optional] 
**mask** | **string** |  | [optional] 
**state** | **string** |  | [optional] 
**family** | **int** |  | [optional] 
**ippool** | **int** |  | [optional] 
**network** | **int** |  | [optional] 
**host** | **array** |  | [optional] 
**clusterInterface** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


