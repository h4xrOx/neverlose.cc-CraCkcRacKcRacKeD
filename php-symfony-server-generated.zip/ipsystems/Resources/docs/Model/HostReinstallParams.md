# HostReinstallParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os** | **int** |  | [optional] 
**image** | **int** |  | [optional] 
**recipe** | **int** |  | [optional] 
**password** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


