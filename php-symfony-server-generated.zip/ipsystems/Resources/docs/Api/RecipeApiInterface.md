# Installer\Api\RecipeApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](RecipeApiInterface.md#add) | **POST** /recipe | 
[**callList**](RecipeApiInterface.md#callList) | **GET** /recipe | Список рецептов
[**delete**](RecipeApiInterface.md#delete) | **DELETE** /recipe/{recipe_id} | 
[**edit**](RecipeApiInterface.md#edit) | **POST** /recipe/{recipe_id} | 
[**get**](RecipeApiInterface.md#get) | **GET** /recipe/{recipe_id} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.recipe:
        class: Acme\MyBundle\Api\RecipeApi
        tags:
            - { name: "vm.2.0.1.api", api: "recipe" }
    # ...
```

## **add**
> Installer\Model\Id add($recipeParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RecipeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RecipeApiInterface;

class RecipeApi implements RecipeApiInterface
{

    // ...

    /**
     * Implementation of RecipeApiInterface#add
     */
    public function add(RecipeParams $recipeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **recipeParams** | [**Installer\Model\RecipeParams**](../Model/RecipeParams.md)|  |

### Return type

[**Installer\Model\Id**](../Model/Id.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\RecipeList callList()

Список рецептов

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RecipeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RecipeApiInterface;

class RecipeApi implements RecipeApiInterface
{

    // ...

    /**
     * Implementation of RecipeApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\RecipeList**](../Model/RecipeList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Deleted delete($recipeId)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RecipeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RecipeApiInterface;

class RecipeApi implements RecipeApiInterface
{

    // ...

    /**
     * Implementation of RecipeApiInterface#delete
     */
    public function delete($recipeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **recipeId** | **int**|  |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> array edit($recipeId, $recipeUpdateParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RecipeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RecipeApiInterface;

class RecipeApi implements RecipeApiInterface
{

    // ...

    /**
     * Implementation of RecipeApiInterface#edit
     */
    public function edit($recipeId, RecipeUpdateParams $recipeUpdateParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **recipeId** | **int**| ID редактируемого скрипта |
 **recipeUpdateParams** | [**Installer\Model\RecipeUpdateParams**](../Model/RecipeUpdateParams.md)| Параметры для редактирования скрипта |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> array get($recipeId)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RecipeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RecipeApiInterface;

class RecipeApi implements RecipeApiInterface
{

    // ...

    /**
     * Implementation of RecipeApiInterface#get
     */
    public function get($recipeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **recipeId** | **int**|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

