# Installer\Api\IppoolApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callList**](IppoolApiInterface.md#callList) | **GET** /ippool | Список пулов ip адресов
[**delete**](IppoolApiInterface.md#delete) | **DELETE** /ippool/{id} | Удаление пула ip адресов


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.ippool:
        class: Acme\MyBundle\Api\IppoolApi
        tags:
            - { name: "vm.2.0.1.api", api: "ippool" }
    # ...
```

## **callList**
> Installer\Model\IppoolList callList($orderby)

Список пулов ip адресов

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/IppoolApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\IppoolApiInterface;

class IppoolApi implements IppoolApiInterface
{

    // ...

    /**
     * Implementation of IppoolApiInterface#callList
     */
    public function callList($orderby = null)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderby** | **string**| Параметр сортировки пулов | [optional]

### Return type

[**Installer\Model\IppoolList**](../Model/IppoolList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Deleted delete($id)

Удаление пула ip адресов

Удаление пула ip адресов

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/IppoolApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\IppoolApiInterface;

class IppoolApi implements IppoolApiInterface
{

    // ...

    /**
     * Implementation of IppoolApiInterface#delete
     */
    public function delete($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID удаляемого пула ip адресов |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

