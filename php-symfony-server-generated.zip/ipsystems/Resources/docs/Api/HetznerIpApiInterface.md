# Installer\Api\HetznerIpApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete**](HetznerIpApiInterface.md#delete) | **DELETE** /hetzner_ip/{hetzner_ip_id} | Удаление IP адреса


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.hetznerIp:
        class: Acme\MyBundle\Api\HetznerIpApi
        tags:
            - { name: "vm.2.0.1.api", api: "hetznerIp" }
    # ...
```

## **delete**
> array delete($hetznerIpId)

Удаление IP адреса

Удаление IP адреса

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HetznerIpApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HetznerIpApiInterface;

class HetznerIpApi implements HetznerIpApiInterface
{

    // ...

    /**
     * Implementation of HetznerIpApiInterface#delete
     */
    public function delete($hetznerIpId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hetznerIpId** | **int**| ID удаляемого IP адреса |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

