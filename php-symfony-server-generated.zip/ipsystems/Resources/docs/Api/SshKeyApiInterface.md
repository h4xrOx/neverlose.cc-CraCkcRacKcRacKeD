# Installer\Api\SshKeyApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](SshKeyApiInterface.md#add) | **POST** /ssh_key | 
[**callList**](SshKeyApiInterface.md#callList) | **GET** /ssh_key | 
[**delete**](SshKeyApiInterface.md#delete) | **DELETE** ssh_key/{ssh_key_id} | Удаление ssh-ключа


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.sshKey:
        class: Acme\MyBundle\Api\SshKeyApi
        tags:
            - { name: "vm.2.0.1.api", api: "sshKey" }
    # ...
```

## **add**
> array add($sshKeyCreateParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/SshKeyApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\SshKeyApiInterface;

class SshKeyApi implements SshKeyApiInterface
{

    // ...

    /**
     * Implementation of SshKeyApiInterface#add
     */
    public function add(SshKeyCreateParams $sshKeyCreateParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sshKeyCreateParams** | [**Installer\Model\SshKeyCreateParams**](../Model/.md)| Параметры для добавления ssh-ключа |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\SshKeysList callList()



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/SshKeyApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\SshKeyApiInterface;

class SshKeyApi implements SshKeyApiInterface
{

    // ...

    /**
     * Implementation of SshKeyApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\SshKeysList**](../Model/SshKeysList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> array delete($sshKeyId)

Удаление ssh-ключа

Удаление ssh-ключа

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/SshKeyApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\SshKeyApiInterface;

class SshKeyApi implements SshKeyApiInterface
{

    // ...

    /**
     * Implementation of SshKeyApiInterface#delete
     */
    public function delete($sshKeyId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sshKeyId** | **int**| ID удаляемого ssh-ключа |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

