# Installer\Api\RepositoryApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](RepositoryApiInterface.md#add) | **POST** /repository | Создание репозитория
[**callList**](RepositoryApiInterface.md#callList) | **GET** /repository | Список репозиториев кластера
[**delete**](RepositoryApiInterface.md#delete) | **DELETE** /repository/{id} | Удаление репозитория
[**get**](RepositoryApiInterface.md#get) | **GET** /repository/{id} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.repository:
        class: Acme\MyBundle\Api\RepositoryApi
        tags:
            - { name: "vm.2.0.1.api", api: "repository" }
    # ...
```

## **add**
> array add($repositoryParams)

Создание репозитория

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RepositoryApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RepositoryApiInterface;

class RepositoryApi implements RepositoryApiInterface
{

    // ...

    /**
     * Implementation of RepositoryApiInterface#add
     */
    public function add(RepositoryParams $repositoryParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **repositoryParams** | [**Installer\Model\RepositoryParams**](../Model/RepositoryParams.md)| Параметры создаваемого репозитория |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\RepoList callList()

Список репозиториев кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RepositoryApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RepositoryApiInterface;

class RepositoryApi implements RepositoryApiInterface
{

    // ...

    /**
     * Implementation of RepositoryApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\RepoList**](../Model/RepoList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Deleted delete($id)

Удаление репозитория

Удаление узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RepositoryApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RepositoryApiInterface;

class RepositoryApi implements RepositoryApiInterface
{

    // ...

    /**
     * Implementation of RepositoryApiInterface#delete
     */
    public function delete($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID удаляемого репозитория |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> array get($id)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/RepositoryApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\RepositoryApiInterface;

class RepositoryApi implements RepositoryApiInterface
{

    // ...

    /**
     * Implementation of RepositoryApiInterface#get
     */
    public function get($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID репозитория |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

