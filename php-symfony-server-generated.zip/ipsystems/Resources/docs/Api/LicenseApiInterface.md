# Installer\Api\LicenseApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**edit**](LicenseApiInterface.md#edit) | **POST** /set_license | Сохранение данных о лицензии
[**get**](LicenseApiInterface.md#get) | **GET** /get_license | Получение данных о лицензии


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.license:
        class: Acme\MyBundle\Api\LicenseApi
        tags:
            - { name: "vm.2.0.1.api", api: "license" }
    # ...
```

## **edit**
> edit($licenseEditParams)

Сохранение данных о лицензии

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/LicenseApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\LicenseApiInterface;

class LicenseApi implements LicenseApiInterface
{

    // ...

    /**
     * Implementation of LicenseApiInterface#edit
     */
    public function edit(License $licenseEditParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **licenseEditParams** | [**Installer\Model\License**](../Model/License.md)| Лицензия |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> Installer\Model\LicenseData get()

Получение данных о лицензии

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/LicenseApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\LicenseApiInterface;

class LicenseApi implements LicenseApiInterface
{

    // ...

    /**
     * Implementation of LicenseApiInterface#get
     */
    public function get()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\LicenseData**](../Model/LicenseData.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

