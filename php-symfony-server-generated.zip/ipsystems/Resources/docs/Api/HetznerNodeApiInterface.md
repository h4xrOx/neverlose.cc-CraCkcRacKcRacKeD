# Installer\Api\HetznerNodeApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addIp**](HetznerNodeApiInterface.md#addIp) | **POST** /node/{node_id}/hetzner_ip | Добавление Ip адресов на узел
[**ipList**](HetznerNodeApiInterface.md#ipList) | **GET** /node/{node_id}/hetzner_ip | Список Ip адресов узла вместе с подсетями и ВМ


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.hetznerNode:
        class: Acme\MyBundle\Api\HetznerNodeApi
        tags:
            - { name: "vm.2.0.1.api", api: "hetznerNode" }
    # ...
```

## **addIp**
> array addIp($nodeId, $addHetznerIpParams)

Добавление Ip адресов на узел

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HetznerNodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HetznerNodeApiInterface;

class HetznerNodeApi implements HetznerNodeApiInterface
{

    // ...

    /**
     * Implementation of HetznerNodeApiInterface#addIp
     */
    public function addIp($nodeId, AddHetznerIpParams $addHetznerIpParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**|  |
 **addHetznerIpParams** | [**Installer\Model\AddHetznerIpParams**](../Model/.md)| Параметры добавляемых IP адресов |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **ipList**
> Installer\Model\HetznerNodeIpList ipList($nodeId)

Список Ip адресов узла вместе с подсетями и ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HetznerNodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HetznerNodeApiInterface;

class HetznerNodeApi implements HetznerNodeApiInterface
{

    // ...

    /**
     * Implementation of HetznerNodeApiInterface#ipList
     */
    public function ipList($nodeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**|  |

### Return type

[**Installer\Model\HetznerNodeIpList**](../Model/HetznerNodeIpList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

