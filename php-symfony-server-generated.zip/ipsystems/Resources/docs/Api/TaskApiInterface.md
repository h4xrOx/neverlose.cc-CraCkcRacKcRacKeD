# Installer\Api\TaskApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callList**](TaskApiInterface.md#callList) | **GET** /task | 
[**delete**](TaskApiInterface.md#delete) | **DELETE** /task/{task_id}/delete | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.task:
        class: Acme\MyBundle\Api\TaskApi
        tags:
            - { name: "vm.2.0.1.api", api: "task" }
    # ...
```

## **callList**
> Installer\Model\TaskList callList()



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/TaskApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\TaskApiInterface;

class TaskApi implements TaskApiInterface
{

    // ...

    /**
     * Implementation of TaskApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\TaskList**](../Model/TaskList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> array delete($taskId)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/TaskApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\TaskApiInterface;

class TaskApi implements TaskApiInterface
{

    // ...

    /**
     * Implementation of TaskApiInterface#delete
     */
    public function delete($taskId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **taskId** | **int**|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

