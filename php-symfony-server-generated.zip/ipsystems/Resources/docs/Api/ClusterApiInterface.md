# Installer\Api\ClusterApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](ClusterApiInterface.md#add) | **POST** /cluster | Создание кластера
[**callList**](ClusterApiInterface.md#callList) | **GET** /cluster | Список кластеров
[**delete**](ClusterApiInterface.md#delete) | **DELETE** /cluster/{id} | Удаление кластера
[**edit**](ClusterApiInterface.md#edit) | **POST** /cluster/{id} | Редактирование кластера
[**get**](ClusterApiInterface.md#get) | **GET** /cluster/{id} | Кластер
[**ippool**](ClusterApiInterface.md#ippool) | **POST** /cluster/{cluster_id}/ippool | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.cluster:
        class: Acme\MyBundle\Api\ClusterApi
        tags:
            - { name: "vm.2.0.1.api", api: "cluster" }
    # ...
```

## **add**
> array add($clusterParams, $cookie)

Создание кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterApiInterface;

class ClusterApi implements ClusterApiInterface
{

    // ...

    /**
     * Implementation of ClusterApiInterface#add
     */
    public function add(ClusterParams $clusterParams, $cookie = null)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clusterParams** | [**Installer\Model\ClusterParams**](../Model/ClusterParams.md)| Параметры создаваемого кластера |
 **cookie** | **string**| Авторизация в куки ses6&#x3D;XXXXXXX | [optional]

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\ClusterList callList($cookie)

Список кластеров

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterApiInterface;

class ClusterApi implements ClusterApiInterface
{

    // ...

    /**
     * Implementation of ClusterApiInterface#callList
     */
    public function callList($cookie = null)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cookie** | **string**| Авторизация в куки ses6&#x3D;XXXXXX | [optional]

### Return type

[**Installer\Model\ClusterList**](../Model/ClusterList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Deleted delete($id)

Удаление кластера

Удаление кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterApiInterface;

class ClusterApi implements ClusterApiInterface
{

    // ...

    /**
     * Implementation of ClusterApiInterface#delete
     */
    public function delete($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID удаляемого кластера |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> array edit($id, $clusterEditParams)

Редактирование кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterApiInterface;

class ClusterApi implements ClusterApiInterface
{

    // ...

    /**
     * Implementation of ClusterApiInterface#edit
     */
    public function edit($id, ClusterEditParams $clusterEditParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID кластера |
 **clusterEditParams** | [**Installer\Model\ClusterEditParams**](../Model/ClusterEditParams.md)| Параметры кластера |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> array get($id)

Кластер

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterApiInterface;

class ClusterApi implements ClusterApiInterface
{

    // ...

    /**
     * Implementation of ClusterApiInterface#get
     */
    public function get($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID кластера |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **ippool**
> ippool($clusterId, $clusterIppoolParams)



Подключение/отключение пулов к кластеру

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterApiInterface;

class ClusterApi implements ClusterApiInterface
{

    // ...

    /**
     * Implementation of ClusterApiInterface#ippool
     */
    public function ippool($clusterId, ClusterIppoolParams $clusterIppoolParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clusterId** | **int**|  |
 **clusterIppoolParams** | [**Installer\Model\ClusterIppoolParams**](../Model/ClusterIppoolParams.md)| Параметры подключения пулов к кластеру |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

