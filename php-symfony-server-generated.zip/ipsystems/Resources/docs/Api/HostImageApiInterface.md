# Installer\Api\HostImageApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](HostImageApiInterface.md#add) | **POST** /host/{host_id}/image/create | Создание образа ВМ
[**callList**](HostImageApiInterface.md#callList) | **GET** /image | Список образов ВМ
[**copy**](HostImageApiInterface.md#copy) | **POST** /image/{image_id}/copy | Копирование образа ВМ
[**delete**](HostImageApiInterface.md#delete) | **DELETE** /image/{image_id} | Удаление образа ВМ
[**edit**](HostImageApiInterface.md#edit) | **POST** /image/{image_id} | Редактирование образа ВМ
[**get**](HostImageApiInterface.md#get) | **GET** /image/{image_id} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.hostImage:
        class: Acme\MyBundle\Api\HostImageApi
        tags:
            - { name: "vm.2.0.1.api", api: "hostImage" }
    # ...
```

## **add**
> array add($hostId, $hostImageParams, $cookie)

Создание образа ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostImageApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostImageApiInterface;

class HostImageApi implements HostImageApiInterface
{

    // ...

    /**
     * Implementation of HostImageApiInterface#add
     */
    public function add($hostId, HostImageParams $hostImageParams, $cookie = null)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID ВМ из которой создаётся образ |
 **hostImageParams** | [**Installer\Model\HostImageParams**](../Model/HostImageParams.md)| Параметры создаваемого образа ВМ |
 **cookie** | **string**| Авторизация в куки ses6&#x3D;XXXXXXX | [optional]

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\HostImageList callList($cookie)

Список образов ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostImageApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostImageApiInterface;

class HostImageApi implements HostImageApiInterface
{

    // ...

    /**
     * Implementation of HostImageApiInterface#callList
     */
    public function callList($cookie = null)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cookie** | **string**| Авторизация в куки ses6&#x3D;XXXXXX | [optional]

### Return type

[**Installer\Model\HostImageList**](../Model/HostImageList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **copy**
> array copy($imageId, $imageCopyParams)

Копирование образа ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostImageApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostImageApiInterface;

class HostImageApi implements HostImageApiInterface
{

    // ...

    /**
     * Implementation of HostImageApiInterface#copy
     */
    public function copy($imageId, ImageCopyParams $imageCopyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **imageId** | **int**| ID образа ВМ |
 **imageCopyParams** | [**Installer\Model\ImageCopyParams**](../Model/.md)| Параметры для копирования образа |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> array delete($imageId)

Удаление образа ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostImageApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostImageApiInterface;

class HostImageApi implements HostImageApiInterface
{

    // ...

    /**
     * Implementation of HostImageApiInterface#delete
     */
    public function delete($imageId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **imageId** | **int**| ID удаляемого образа ВМ |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> array edit($imageId, $imageChangeParams)

Редактирование образа ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostImageApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostImageApiInterface;

class HostImageApi implements HostImageApiInterface
{

    // ...

    /**
     * Implementation of HostImageApiInterface#edit
     */
    public function edit($imageId, ImageChangeParams $imageChangeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **imageId** | **int**| ID редактируемого образа ВМ |
 **imageChangeParams** | [**Installer\Model\ImageChangeParams**](../Model/ImageChangeParams.md)| Параметры для редактирования образа |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> array get($imageId)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostImageApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostImageApiInterface;

class HostImageApi implements HostImageApiInterface
{

    // ...

    /**
     * Implementation of HostImageApiInterface#get
     */
    public function get($imageId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **imageId** | **int**|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

