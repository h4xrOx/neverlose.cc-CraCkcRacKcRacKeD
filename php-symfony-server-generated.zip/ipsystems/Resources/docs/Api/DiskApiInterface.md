# Installer\Api\DiskApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**resize**](DiskApiInterface.md#resize) | **POST** /disk/{id} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.disk:
        class: Acme\MyBundle\Api\DiskApi
        tags:
            - { name: "vm.2.0.1.api", api: "disk" }
    # ...
```

## **resize**
> array resize($id, $diskResizeParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/DiskApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\DiskApiInterface;

class DiskApi implements DiskApiInterface
{

    // ...

    /**
     * Implementation of DiskApiInterface#resize
     */
    public function resize($id, DiskResizeParams $diskResizeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |
 **diskResizeParams** | [**Installer\Model\DiskResizeParams**](../Model/.md)| Параметры для изменения диска |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

