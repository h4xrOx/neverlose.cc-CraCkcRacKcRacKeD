# Installer\Api\ClusterSshKeyApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sshKey**](ClusterSshKeyApiInterface.md#sshKey) | **POST** /cluster/{cluster_id}/ssh_key | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.clusterSshKey:
        class: Acme\MyBundle\Api\ClusterSshKeyApi
        tags:
            - { name: "vm.2.0.1.api", api: "clusterSshKey" }
    # ...
```

## **sshKey**
> array sshKey($clusterId, $sshKeyClusterParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ClusterSshKeyApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\ClusterSshKeyApiInterface;

class ClusterSshKeyApi implements ClusterSshKeyApiInterface
{

    // ...

    /**
     * Implementation of ClusterSshKeyApiInterface#sshKey
     */
    public function sshKey($clusterId, SshKeyClusterParams $sshKeyClusterParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clusterId** | **int**|  |
 **sshKeyClusterParams** | [**Installer\Model\SshKeyClusterParams**](../Model/.md)| Параметры для подключения ssh-ключей к кластеру |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

