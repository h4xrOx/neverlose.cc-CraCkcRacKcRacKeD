# Installer\Api\NodeApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](NodeApiInterface.md#add) | **POST** /node | Создание узла кластера
[**callList**](NodeApiInterface.md#callList) | **GET** /node | Список узлов кластера
[**delete**](NodeApiInterface.md#delete) | **DELETE** /node/{node_id} | Удаление узла кластера
[**edit**](NodeApiInterface.md#edit) | **POST** /node/{node_id} | 
[**get**](NodeApiInterface.md#get) | **GET** /node/{node_id} | Содержимое узла кластера
[**runScript**](NodeApiInterface.md#runScript) | **POST** /node/{node_id}/run_script | Запуск скрипта на узле
[**updateCertificates**](NodeApiInterface.md#updateCertificates) | **POST** /node/{node_id}/cert | Обновление libvirt сертификатов на узле


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.node:
        class: Acme\MyBundle\Api\NodeApi
        tags:
            - { name: "vm.2.0.1.api", api: "node" }
    # ...
```

## **add**
> array add($nodeParams)

Создание узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#add
     */
    public function add(NodeParams $nodeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeParams** | [**Installer\Model\NodeParams**](../Model/NodeParams.md)| Параметры создаваемого узла кластера |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\NodeList callList()

Список узлов кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\NodeList**](../Model/NodeList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> array delete($nodeId)

Удаление узла кластера

Удаление узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#delete
     */
    public function delete($nodeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**| ID удаляемого узла кластера |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> array edit($nodeId, $nodeUpdateParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#edit
     */
    public function edit($nodeId, NodeUpdateParams $nodeUpdateParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**| ID редактируемого узла |
 **nodeUpdateParams** | [**Installer\Model\NodeUpdateParams**](../Model/NodeUpdateParams.md)| Параметры для редактирования узла |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> array get($nodeId)

Содержимое узла кластера

Содержимое узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#get
     */
    public function get($nodeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**| ID узла кластера |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **runScript**
> array runScript($nodeId, $nodeRunScriptParams)

Запуск скрипта на узле

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#runScript
     */
    public function runScript($nodeId, NodeRunScriptParams $nodeRunScriptParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**| ID узла |
 **nodeRunScriptParams** | [**Installer\Model\NodeRunScriptParams**](../Model/.md)| Параметры запускаемого скрипта |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **updateCertificates**
> array updateCertificates($nodeId)

Обновление libvirt сертификатов на узле

Обновление libvirt сертификатов на узле

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeApiInterface;

class NodeApi implements NodeApiInterface
{

    // ...

    /**
     * Implementation of NodeApiInterface#updateCertificates
     */
    public function updateCertificates($nodeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**| ID узла для обновления сертификатов |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

