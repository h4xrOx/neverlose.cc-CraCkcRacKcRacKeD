# Installer\Api\NodeScriptApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](NodeScriptApiInterface.md#add) | **POST** /node_script | Создание скрипта для узла кластера
[**callList**](NodeScriptApiInterface.md#callList) | **GET** /node_script | Список скриптов
[**delete**](NodeScriptApiInterface.md#delete) | **DELETE** /node_script/{node_script_id} | Удаление скрипта для узла кластера
[**edit**](NodeScriptApiInterface.md#edit) | **POST** /node_script/{node_script_id} | Редактирование скрипта для узла кластера
[**get**](NodeScriptApiInterface.md#get) | **GET** /node_script/{node_script_id} | Скрипт для узла кластера


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.nodeScript:
        class: Acme\MyBundle\Api\NodeScriptApi
        tags:
            - { name: "vm.2.0.1.api", api: "nodeScript" }
    # ...
```

## **add**
> array add($nodeScriptCreateParams)

Создание скрипта для узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeScriptApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeScriptApiInterface;

class NodeScriptApi implements NodeScriptApiInterface
{

    // ...

    /**
     * Implementation of NodeScriptApiInterface#add
     */
    public function add(NodeScriptParams $nodeScriptCreateParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeScriptCreateParams** | [**Installer\Model\NodeScriptParams**](../Model/NodeScriptParams.md)| Параметры скрипта |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\NodeScriptList callList()

Список скриптов

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeScriptApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeScriptApiInterface;

class NodeScriptApi implements NodeScriptApiInterface
{

    // ...

    /**
     * Implementation of NodeScriptApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\NodeScriptList**](../Model/NodeScriptList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Deleted delete($nodeScriptId)

Удаление скрипта для узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeScriptApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeScriptApiInterface;

class NodeScriptApi implements NodeScriptApiInterface
{

    // ...

    /**
     * Implementation of NodeScriptApiInterface#delete
     */
    public function delete($nodeScriptId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeScriptId** | **int**| ID редактируемого скрипта |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> edit($nodeScriptEditParams, $nodeScriptId)

Редактирование скрипта для узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeScriptApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeScriptApiInterface;

class NodeScriptApi implements NodeScriptApiInterface
{

    // ...

    /**
     * Implementation of NodeScriptApiInterface#edit
     */
    public function edit(NodeScriptParams $nodeScriptEditParams, $nodeScriptId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeScriptEditParams** | [**Installer\Model\NodeScriptParams**](../Model/NodeScriptParams.md)| Параметры скрипта |
 **nodeScriptId** | **int**| ID редактируемого скрипта |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> Installer\Model\NodeScriptParams get($nodeScriptId)

Скрипт для узла кластера

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeScriptApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeScriptApiInterface;

class NodeScriptApi implements NodeScriptApiInterface
{

    // ...

    /**
     * Implementation of NodeScriptApiInterface#get
     */
    public function get($nodeScriptId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeScriptId** | **int**| ID редактируемого скрипта |

### Return type

[**Installer\Model\NodeScriptParams**](../Model/NodeScriptParams.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

