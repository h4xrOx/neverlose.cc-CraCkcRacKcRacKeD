# Installer\Api\HostApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](HostApiInterface.md#add) | **POST** /host | Создание ВМ
[**addIp**](HostApiInterface.md#addIp) | **POST** /host/{host_id}/ip | 
[**callClone**](HostApiInterface.md#callClone) | **POST** /host/{host_id}/clone | 
[**callList**](HostApiInterface.md#callList) | **GET** /host | 
[**changeAccount**](HostApiInterface.md#changeAccount) | **POST** /host/{host_id}/account | 
[**changePassword**](HostApiInterface.md#changePassword) | **POST** /host/{host_id}/password | 
[**delete**](HostApiInterface.md#delete) | **DELETE** /host/{host_id} | Удаление ВМ
[**deleteIp**](HostApiInterface.md#deleteIp) | **DELETE** /ip/{ip_id} | Удаление IP адреса
[**edit**](HostApiInterface.md#edit) | **POST** /host/{host_id} | Редактирование ВМ
[**editResource**](HostApiInterface.md#editResource) | **POST** /host/{host_id}/resource | 
[**get**](HostApiInterface.md#get) | **GET** /host/{host_id} | 
[**getHostHistory**](HostApiInterface.md#getHostHistory) | **GET** /host/{host_id}/history | 
[**ipList**](HostApiInterface.md#ipList) | **GET** /ip | 
[**isoCancel**](HostApiInterface.md#isoCancel) | **POST** /host/{host_id}/iso/cancel | Отключение ISO от ВМ без переустановки
[**isoFinish**](HostApiInterface.md#isoFinish) | **POST** /host/{host_id}/iso/finish | Отключение ISO от ВМ с переустановкой
[**isoMount**](HostApiInterface.md#isoMount) | **POST** /host/{host_id}/iso/mount | Подключение ISO к ВМ
[**migrate**](HostApiInterface.md#migrate) | **POST** /host/{host_id}/migrate | 
[**reinstall**](HostApiInterface.md#reinstall) | **POST** /host/{id}/reinstall | 
[**rescueMode**](HostApiInterface.md#rescueMode) | **POST** /host/{host_id}/rescue_mode | 
[**restart**](HostApiInterface.md#restart) | **POST** /host/{host_id}/restart | 
[**runrecipe**](HostApiInterface.md#runrecipe) | **POST** /host/{id}/runrecipe | 
[**setImageGibLimit**](HostApiInterface.md#setImageGibLimit) | **POST** /host/{id}/bill_option/image_gib | 
[**start**](HostApiInterface.md#start) | **POST** /host/{host_id}/start | 
[**stop**](HostApiInterface.md#stop) | **POST** /host/{host_id}/stop | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.host:
        class: Acme\MyBundle\Api\HostApi
        tags:
            - { name: "vm.2.0.1.api", api: "host" }
    # ...
```

## **add**
> array add($hostParams)

Создание ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#add
     */
    public function add(HostParams $hostParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostParams** | [**Installer\Model\HostParams**](../Model/HostParams.md)| Параметры создаваемой ВМ |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **addIp**
> array addIp($hostId, $addIpParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#addIp
     */
    public function addIp($hostId, AddIpParams $addIpParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |
 **addIpParams** | [**Installer\Model\AddIpParams**](../Model/AddIpParams.md)| Параметры добавляемых IP адресов |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callClone**
> array callClone($hostId, $emptyParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#callClone
     */
    public function callClone($hostId, EmptyParams $emptyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **emptyParams** | [**Installer\Model\EmptyParams**](../Model/EmptyParams.md)| Пустые параметры |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\HostList callList()



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\HostList**](../Model/HostList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **changeAccount**
> array changeAccount($hostId, $hostAccountParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#changeAccount
     */
    public function changeAccount($hostId, HostAccountParams $hostAccountParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **hostAccountParams** | [**Installer\Model\HostAccountParams**](../Model/.md)| Параметры смены владельца |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **changePassword**
> changePassword($hostId, $hostChangePasswordParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#changePassword
     */
    public function changePassword($hostId, HostChangePasswordParams $hostChangePasswordParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **hostChangePasswordParams** | [**Installer\Model\HostChangePasswordParams**](../Model/.md)| Параметры для смены пароля |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> array delete($hostId)

Удаление ВМ

Удаление хоста

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#delete
     */
    public function delete($hostId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID удаляемого хоста |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **deleteIp**
> array deleteIp($hostId, $ipId)

Удаление IP адреса

Удаление IP адреса

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#deleteIp
     */
    public function deleteIp($hostId, $ipId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID ВМ |
 **ipId** | **int**| ID удаляемого IP адреса |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> array edit($hostId, $hostChangeParams)

Редактирование ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#edit
     */
    public function edit($hostId, HostChangeParams $hostChangeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID редактируемой ВМ |
 **hostChangeParams** | [**Installer\Model\HostChangeParams**](../Model/HostChangeParams.md)| Параметры для редактирования ВМ |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **editResource**
> array editResource($hostId, $hostResourceParams)



Изменение параметров Хоста

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#editResource
     */
    public function editResource($hostId, HostResourceParams $hostResourceParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **hostResourceParams** | [**Installer\Model\HostResourceParams**](../Model/HostResourceParams.md)| Параметры для изменения хоста |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> array get($hostId)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#get
     */
    public function get($hostId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getHostHistory**
> array getHostHistory($hostId)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#getHostHistory
     */
    public function getHostHistory($hostId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **ipList**
> Installer\Model\IpList ipList()



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#ipList
     */
    public function ipList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\IpList**](../Model/IpList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **isoCancel**
> array isoCancel($hostId, $emptyParams)

Отключение ISO от ВМ без переустановки

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#isoCancel
     */
    public function isoCancel($hostId, EmptyParams $emptyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |
 **emptyParams** | [**Installer\Model\EmptyParams**](../Model/EmptyParams.md)| Пустые параметры |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **isoFinish**
> array isoFinish($hostId, $emptyParams)

Отключение ISO от ВМ с переустановкой

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#isoFinish
     */
    public function isoFinish($hostId, EmptyParams $emptyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |
 **emptyParams** | [**Installer\Model\EmptyParams**](../Model/EmptyParams.md)| Пустые параметры |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **isoMount**
> array isoMount($hostId, $hostIsoMountParams)

Подключение ISO к ВМ

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#isoMount
     */
    public function isoMount($hostId, HostIsoMountParams $hostIsoMountParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |
 **hostIsoMountParams** | [**Installer\Model\HostIsoMountParams**](../Model/.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **migrate**
> array migrate($hostId, $hostMigrateParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#migrate
     */
    public function migrate($hostId, HostMigrateParams $hostMigrateParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **hostMigrateParams** | [**Installer\Model\HostMigrateParams**](../Model/.md)| Параметры миграции |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **reinstall**
> array reinstall($id, $hostReinstallParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#reinstall
     */
    public function reinstall($id, HostReinstallParams $hostReinstallParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |
 **hostReinstallParams** | [**Installer\Model\HostReinstallParams**](../Model/HostReinstallParams.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **rescueMode**
> array rescueMode($hostId, $hostRescueModeParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#rescueMode
     */
    public function rescueMode($hostId, HostRescueModeParams $hostRescueModeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**|  |
 **hostRescueModeParams** | [**Installer\Model\HostRescueModeParams**](../Model/.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **restart**
> array restart($hostId, $emptyParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#restart
     */
    public function restart($hostId, EmptyParams $emptyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **emptyParams** | [**Installer\Model\EmptyParams**](../Model/EmptyParams.md)| Пустые параметры |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **runrecipe**
> array runrecipe($id, $hostRunRecipeParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#runrecipe
     */
    public function runrecipe($id, HostRunRecipeParams $hostRunRecipeParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |
 **hostRunRecipeParams** | [**Installer\Model\HostRunRecipeParams**](../Model/HostRunRecipeParams.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **setImageGibLimit**
> array setImageGibLimit($id, $hostBillOptionImageGib)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#setImageGibLimit
     */
    public function setImageGibLimit($id, HostBillOptionImageGib $hostBillOptionImageGib)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |
 **hostBillOptionImageGib** | [**Installer\Model\HostBillOptionImageGib**](../Model/HostBillOptionImageGib.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **start**
> array start($hostId, $emptyParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#start
     */
    public function start($hostId, EmptyParams $emptyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **emptyParams** | [**Installer\Model\EmptyParams**](../Model/EmptyParams.md)| Пустые параметры |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **stop**
> array stop($hostId, $emptyParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HostApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HostApiInterface;

class HostApi implements HostApiInterface
{

    // ...

    /**
     * Implementation of HostApiInterface#stop
     */
    public function stop($hostId, EmptyParams $emptyParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hostId** | **int**| ID хоста |
 **emptyParams** | [**Installer\Model\EmptyParams**](../Model/EmptyParams.md)| Пустые параметры |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

