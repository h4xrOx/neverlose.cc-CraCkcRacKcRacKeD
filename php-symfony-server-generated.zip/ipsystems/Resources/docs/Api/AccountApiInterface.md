# Installer\Api\AccountApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountGet**](AccountApiInterface.md#accountGet) | **GET** /account | Список аккаунтов
[**add**](AccountApiInterface.md#add) | **POST** /account | Создание аккаунта


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.account:
        class: Acme\MyBundle\Api\AccountApi
        tags:
            - { name: "vm.2.0.1.api", api: "account" }
    # ...
```

## **accountGet**
> Installer\Model\AccountList accountGet()

Список аккаунтов

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/AccountApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\AccountApiInterface;

class AccountApi implements AccountApiInterface
{

    // ...

    /**
     * Implementation of AccountApiInterface#accountGet
     */
    public function accountGet()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\AccountList**](../Model/AccountList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **add**
> array add($accountParams)

Создание аккаунта

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/AccountApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\AccountApiInterface;

class AccountApi implements AccountApiInterface
{

    // ...

    /**
     * Implementation of AccountApiInterface#add
     */
    public function add(AccountParams $accountParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountParams** | [**Installer\Model\AccountParams**](../Model/AccountParams.md)| Параметры создаваемого аккаунта |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

