# Installer\Api\NodeFilesApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**filesList**](NodeFilesApiInterface.md#filesList) | **GET** /node/{node_id}/files | Получение списка файлов с узла


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.nodeFiles:
        class: Acme\MyBundle\Api\NodeFilesApi
        tags:
            - { name: "vm.2.0.1.api", api: "nodeFiles" }
    # ...
```

## **filesList**
> Installer\Model\NodeFileList filesList($nodeId)

Получение списка файлов с узла

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/NodeFilesApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\NodeFilesApiInterface;

class NodeFilesApi implements NodeFilesApiInterface
{

    // ...

    /**
     * Implementation of NodeFilesApiInterface#filesList
     */
    public function filesList($nodeId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nodeId** | **int**| ID запрашиваемого узла |

### Return type

[**Installer\Model\NodeFileList**](../Model/NodeFileList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

