# Installer\Api\PresetApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](PresetApiInterface.md#add) | **POST** /preset | 
[**callList**](PresetApiInterface.md#callList) | **GET** /preset | 
[**delete**](PresetApiInterface.md#delete) | **DELETE** /preset/{id} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.preset:
        class: Acme\MyBundle\Api\PresetApi
        tags:
            - { name: "vm.2.0.1.api", api: "preset" }
    # ...
```

## **add**
> Installer\Model\Id add($presetParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/PresetApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\PresetApiInterface;

class PresetApi implements PresetApiInterface
{

    // ...

    /**
     * Implementation of PresetApiInterface#add
     */
    public function add(PresetParams $presetParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **presetParams** | [**Installer\Model\PresetParams**](../Model/PresetParams.md)|  |

### Return type

[**Installer\Model\Id**](../Model/Id.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **callList**
> Installer\Model\PresetList callList()



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/PresetApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\PresetApiInterface;

class PresetApi implements PresetApiInterface
{

    // ...

    /**
     * Implementation of PresetApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\PresetList**](../Model/PresetList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Id delete($id)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/PresetApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\PresetApiInterface;

class PresetApi implements PresetApiInterface
{

    // ...

    /**
     * Implementation of PresetApiInterface#delete
     */
    public function delete($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |

### Return type

[**Installer\Model\Id**](../Model/Id.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

