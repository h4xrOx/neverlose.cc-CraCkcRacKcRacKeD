# Installer\Api\OsApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callList**](OsApiInterface.md#callList) | **GET** /os | Список ОС
[**delete**](OsApiInterface.md#delete) | **DELETE** /os/{id} | Удаление ОС
[**edit**](OsApiInterface.md#edit) | **POST** /os/{id} | Редактирование ОС


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.os:
        class: Acme\MyBundle\Api\OsApi
        tags:
            - { name: "vm.2.0.1.api", api: "os" }
    # ...
```

## **callList**
> Installer\Model\OSList callList()

Список ОС

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/OsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\OsApiInterface;

class OsApi implements OsApiInterface
{

    // ...

    /**
     * Implementation of OsApiInterface#callList
     */
    public function callList()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\OSList**](../Model/OSList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **delete**
> Installer\Model\Deleted delete($id)

Удаление ОС

Удаление ОС

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/OsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\OsApiInterface;

class OsApi implements OsApiInterface
{

    // ...

    /**
     * Implementation of OsApiInterface#delete
     */
    public function delete($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID удаляемой ОС |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **edit**
> array edit($id, $oSEditParams)

Редактирование ОС

Редактирование Ос

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/OsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\OsApiInterface;

class OsApi implements OsApiInterface
{

    // ...

    /**
     * Implementation of OsApiInterface#edit
     */
    public function edit($id, OSEditParams $oSEditParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID редактируемой ОС |
 **oSEditParams** | [**Installer\Model\OSEditParams**](../Model/OSEditParams.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

