# Installer\Api\UserLimitsApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addForAccount**](UserLimitsApiInterface.md#addForAccount) | **POST** /user_limits/account/{account_name} | 
[**addForRole**](UserLimitsApiInterface.md#addForRole) | **POST** /user_limits/role/{role_name} | 
[**deleteForAccount**](UserLimitsApiInterface.md#deleteForAccount) | **DELETE** /user_limits/account/{account_name} | 
[**deleteForRole**](UserLimitsApiInterface.md#deleteForRole) | **DELETE** /user_limits/role/{role_name} | 
[**get**](UserLimitsApiInterface.md#get) | **GET** /user_limits | 
[**getForAccount**](UserLimitsApiInterface.md#getForAccount) | **GET** /user_limits/account/{account_name} | 
[**getForRole**](UserLimitsApiInterface.md#getForRole) | **GET** /user_limits/role/{role_name} | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.userLimits:
        class: Acme\MyBundle\Api\UserLimitsApi
        tags:
            - { name: "vm.2.0.1.api", api: "userLimits" }
    # ...
```

## **addForAccount**
> array addForAccount($accountName, $userLimitsParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#addForAccount
     */
    public function addForAccount($accountName, UserLimitsAdmin $userLimitsParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountName** | **string**|  |
 **userLimitsParams** | [**Installer\Model\UserLimitsAdmin**](../Model/UserLimitsAdmin.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **addForRole**
> array addForRole($roleName, $userLimitsParams)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#addForRole
     */
    public function addForRole($roleName, UserLimitsAdmin $userLimitsParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleName** | **string**|  |
 **userLimitsParams** | [**Installer\Model\UserLimitsAdmin**](../Model/UserLimitsAdmin.md)|  |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **deleteForAccount**
> Installer\Model\Deleted deleteForAccount($accountName)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#deleteForAccount
     */
    public function deleteForAccount($accountName)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountName** | **string**|  |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **deleteForRole**
> Installer\Model\Deleted deleteForRole($roleName)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#deleteForRole
     */
    public function deleteForRole($roleName)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleName** | **string**|  |

### Return type

[**Installer\Model\Deleted**](../Model/Deleted.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **get**
> Installer\Model\UserLimits get()



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#get
     */
    public function get()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Installer\Model\UserLimits**](../Model/UserLimits.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getForAccount**
> Installer\Model\UserLimitsAdmin getForAccount($accountName)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#getForAccount
     */
    public function getForAccount($accountName)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountName** | **string**|  |

### Return type

[**Installer\Model\UserLimitsAdmin**](../Model/UserLimitsAdmin.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getForRole**
> Installer\Model\UserLimitsAdmin getForRole($roleName)



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UserLimitsApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\UserLimitsApiInterface;

class UserLimitsApi implements UserLimitsApiInterface
{

    // ...

    /**
     * Implementation of UserLimitsApiInterface#getForRole
     */
    public function getForRole($roleName)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleName** | **string**|  |

### Return type

[**Installer\Model\UserLimitsAdmin**](../Model/UserLimitsAdmin.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

