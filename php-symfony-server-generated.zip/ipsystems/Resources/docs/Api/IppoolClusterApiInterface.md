# Installer\Api\IppoolClusterApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**callList**](IppoolClusterApiInterface.md#callList) | **GET** /ippool/{ippool_id}/cluster | 
[**cluster**](IppoolClusterApiInterface.md#cluster) | **POST** /ippool/{ippool_id}/cluster | 


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.ippoolCluster:
        class: Acme\MyBundle\Api\IppoolClusterApi
        tags:
            - { name: "vm.2.0.1.api", api: "ippoolCluster" }
    # ...
```

## **callList**
> Installer\Model\IppoolClusterList callList($ippoolId)



Список кластеров к котром подключен пул

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/IppoolClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\IppoolClusterApiInterface;

class IppoolClusterApi implements IppoolClusterApiInterface
{

    // ...

    /**
     * Implementation of IppoolClusterApiInterface#callList
     */
    public function callList($ippoolId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ippoolId** | **int**|  |

### Return type

[**Installer\Model\IppoolClusterList**](../Model/IppoolClusterList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **cluster**
> cluster($ippoolId, $ippoolClusterParams)



Подключение пула к кластерам

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/IppoolClusterApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\IppoolClusterApiInterface;

class IppoolClusterApi implements IppoolClusterApiInterface
{

    // ...

    /**
     * Implementation of IppoolClusterApiInterface#cluster
     */
    public function cluster($ippoolId, IppoolClusterParams $ippoolClusterParams)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ippoolId** | **int**|  |
 **ippoolClusterParams** | [**Installer\Model\IppoolClusterParams**](../Model/IppoolClusterParams.md)| Параметры подключения пула к кластерам |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

