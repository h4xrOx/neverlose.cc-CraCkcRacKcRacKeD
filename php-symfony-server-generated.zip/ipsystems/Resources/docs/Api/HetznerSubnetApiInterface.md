# Installer\Api\HetznerSubnetApiInterface

All URIs are relative to *https://virtserver.swaggerhub.com/gamesense.is/is-psystem_vm_api/3.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete**](HetznerSubnetApiInterface.md#delete) | **DELETE** /hetzner_subnet/{hetzner_subnet_id} | Удаление подсети


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.hetznerSubnet:
        class: Acme\MyBundle\Api\HetznerSubnetApi
        tags:
            - { name: "vm.2.0.1.api", api: "hetznerSubnet" }
    # ...
```

## **delete**
> array delete($hetznerSubnetId)

Удаление подсети

Удаление подсети

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/HetznerSubnetApiInterface.php

namespace Acme\MyBundle\Api;

use Installer\Api\HetznerSubnetApiInterface;

class HetznerSubnetApi implements HetznerSubnetApiInterface
{

    // ...

    /**
     * Implementation of HetznerSubnetApiInterface#delete
     */
    public function delete($hetznerSubnetId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hetznerSubnetId** | **int**| ID удаляемой подсети |

### Return type

**array**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

