'use strict';


/**
 * Добавление Ip адресов на узел
 *
 * node_id Integer 
 * addHetznerIpParams AddHetznerIpParams Параметры добавляемых IP адресов
 * returns Object
 **/
exports.add_ip = function(node_id,addHetznerIpParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Список Ip адресов узла вместе с подсетями и ВМ
 *
 * node_id Integer 
 * returns HetznerNodeIpList
 **/
exports.ip_list = function(node_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

