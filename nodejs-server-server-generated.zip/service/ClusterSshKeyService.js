'use strict';


/**
 *
 * cluster_id Integer 
 * sshKeyClusterParams SshKeyClusterParams Параметры для подключения ssh-ключей к кластеру
 * returns Object
 **/
exports.ssh_key = function(cluster_id,sshKeyClusterParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

