'use strict';


/**
 * Удаление подсети
 * Удаление подсети
 *
 * hetzner_subnet_id Integer ID удаляемой подсети
 * returns Object
 **/
exports.delete = function(hetzner_subnet_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

