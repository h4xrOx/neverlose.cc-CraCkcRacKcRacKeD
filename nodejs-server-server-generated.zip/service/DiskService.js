'use strict';


/**
 *
 * id Integer 
 * diskResizeParams DiskResizeParams Параметры для изменения диска
 * returns Object
 **/
exports.resize = function(id,diskResizeParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

