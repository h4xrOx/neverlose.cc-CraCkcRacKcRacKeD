'use strict';


/**
 * Сохранение данных о лицензии
 *
 * licenseEditParams License Лицензия
 * no response value expected for this operation
 **/
exports.edit = function(licenseEditParams) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Получение данных о лицензии
 *
 * returns LicenseData
 **/
exports.get = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

