'use strict';


/**
 * Получение списка файлов с узла
 *
 * node_id Integer ID запрашиваемого узла
 * returns NodeFileList
 **/
exports.files_list = function(node_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

