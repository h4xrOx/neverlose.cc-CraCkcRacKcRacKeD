'use strict';


/**
 * Удаление IP адреса
 * Удаление IP адреса
 *
 * hetzner_ip_id Integer ID удаляемого IP адреса
 * returns Object
 **/
exports.delete = function(hetzner_ip_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

