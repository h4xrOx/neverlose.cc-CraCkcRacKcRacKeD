'use strict';


/**
 * Создание скрипта для узла кластера
 *
 * nodeScriptCreateParams NodeScriptParams Параметры скрипта
 * returns Object
 **/
exports.add = function(nodeScriptCreateParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Удаление скрипта для узла кластера
 *
 * node_script_id Integer ID редактируемого скрипта
 * returns Deleted
 **/
exports.delete = function(node_script_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Редактирование скрипта для узла кластера
 *
 * nodeScriptEditParams NodeScriptParams Параметры скрипта
 * node_script_id Integer ID редактируемого скрипта
 * no response value expected for this operation
 **/
exports.edit = function(nodeScriptEditParams,node_script_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Скрипт для узла кластера
 *
 * node_script_id Integer ID редактируемого скрипта
 * returns NodeScriptParams
 **/
exports.get = function(node_script_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Список скриптов
 *
 * returns NodeScriptList
 **/
exports.list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

