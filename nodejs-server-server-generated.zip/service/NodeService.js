'use strict';


/**
 * Создание узла кластера
 *
 * nodeParams NodeParams Параметры создаваемого узла кластера
 * returns Object
 **/
exports.add = function(nodeParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Удаление узла кластера
 * Удаление узла кластера
 *
 * node_id Integer ID удаляемого узла кластера
 * returns Object
 **/
exports.delete = function(node_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * node_id Integer ID редактируемого узла
 * nodeUpdateParams NodeUpdateParams Параметры для редактирования узла
 * returns Object
 **/
exports.edit = function(node_id,nodeUpdateParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Содержимое узла кластера
 * Содержимое узла кластера
 *
 * node_id Integer ID узла кластера
 * returns Object
 **/
exports.get = function(node_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Список узлов кластера
 *
 * returns NodeList
 **/
exports.list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Запуск скрипта на узле
 *
 * node_id Integer ID узла
 * node_run_script_params Node_run_script_params Параметры запускаемого скрипта
 * returns Object
 **/
exports.run_script = function(node_id,node_run_script_params) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Обновление libvirt сертификатов на узле
 * Обновление libvirt сертификатов на узле
 *
 * node_id Integer ID узла для обновления сертификатов
 * returns Object
 **/
exports.update_certificates = function(node_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

