'use strict';


/**
 * Создание кластера
 *
 * clusterParams ClusterParams Параметры создаваемого кластера
 * cookie String Авторизация в куки ses6=XXXXXXX (optional)
 * returns Object
 **/
exports.add = function(clusterParams,cookie) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Удаление кластера
 * Удаление кластера
 *
 * id Integer ID удаляемого кластера
 * returns Deleted
 **/
exports.delete = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Редактирование кластера
 *
 * id Integer ID кластера
 * clusterEditParams ClusterEditParams Параметры кластера
 * returns Object
 **/
exports.edit = function(id,clusterEditParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Кластер
 *
 * id Integer ID кластера
 * returns Object
 **/
exports.get = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Подключение/отключение пулов к кластеру
 *
 * cluster_id Integer 
 * clusterIppoolParams ClusterIppoolParams Параметры подключения пулов к кластеру
 * no response value expected for this operation
 **/
exports.ippool = function(cluster_id,clusterIppoolParams) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Список кластеров
 *
 * cookie String Авторизация в куки ses6=XXXXXX (optional)
 * returns ClusterList
 **/
exports.list = function(cookie) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

