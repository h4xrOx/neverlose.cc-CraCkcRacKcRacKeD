'use strict';


/**
 * Удаление пула ip адресов
 * Удаление пула ip адресов
 *
 * id Integer ID удаляемого пула ip адресов
 * returns Deleted
 **/
exports.delete = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Список пулов ip адресов
 *
 * orderby String Параметр сортировки пулов (optional)
 * returns IppoolList
 **/
exports.list = function(orderby) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

