'use strict';


/**
 * Создание ВМ
 *
 * hostParams HostParams Параметры создаваемой ВМ
 * returns Object
 **/
exports.add = function(hostParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer 
 * addIpParams AddIpParams Параметры добавляемых IP адресов
 * returns Object
 **/
exports.add_ip = function(host_id,addIpParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer ID хоста
 * hostAccountParams HostAccountParams Параметры смены владельца
 * returns Object
 **/
exports.change_account = function(host_id,hostAccountParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer ID хоста
 * hostChangePasswordParams HostChangePasswordParams Параметры для смены пароля
 * no response value expected for this operation
 **/
exports.change_password = function(host_id,hostChangePasswordParams) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 *
 * host_id Integer ID хоста
 * emptyParams EmptyParams Пустые параметры
 * returns Object
 **/
exports.clone = function(host_id,emptyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Удаление ВМ
 * Удаление хоста
 *
 * host_id Integer ID удаляемого хоста
 * returns Object
 **/
exports.delete = function(host_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Удаление IP адреса
 * Удаление IP адреса
 *
 * host_id Integer ID ВМ
 * ip_id Integer ID удаляемого IP адреса
 * returns Object
 **/
exports.delete_ip = function(host_id,ip_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Редактирование ВМ
 *
 * host_id Integer ID редактируемой ВМ
 * hostChangeParams HostChangeParams Параметры для редактирования ВМ
 * returns Object
 **/
exports.edit = function(host_id,hostChangeParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Изменение параметров Хоста
 *
 * host_id Integer ID хоста
 * hostResourceParams HostResourceParams Параметры для изменения хоста
 * returns Object
 **/
exports.edit_resource = function(host_id,hostResourceParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer 
 * returns Object
 **/
exports.get = function(host_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer 
 * returns Object
 **/
exports.get_host_history = function(host_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * returns IpList
 **/
exports.ip_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Отключение ISO от ВМ без переустановки
 *
 * host_id Integer 
 * emptyParams EmptyParams Пустые параметры
 * returns Object
 **/
exports.iso_cancel = function(host_id,emptyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Отключение ISO от ВМ с переустановкой
 *
 * host_id Integer 
 * emptyParams EmptyParams Пустые параметры
 * returns Object
 **/
exports.iso_finish = function(host_id,emptyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Подключение ISO к ВМ
 *
 * host_id Integer 
 * hostIsoMountParams HostIsoMountParams 
 * returns Object
 **/
exports.iso_mount = function(host_id,hostIsoMountParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * returns HostList
 **/
exports.list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer ID хоста
 * hostMigrateParams HostMigrateParams Параметры миграции
 * returns Object
 **/
exports.migrate = function(host_id,hostMigrateParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * id Integer 
 * hostReinstallParams HostReinstallParams 
 * returns Object
 **/
exports.reinstall = function(id,hostReinstallParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer 
 * hostRescueModeParams HostRescueModeParams 
 * returns Object
 **/
exports.rescue_mode = function(host_id,hostRescueModeParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer ID хоста
 * emptyParams EmptyParams Пустые параметры
 * returns Object
 **/
exports.restart = function(host_id,emptyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * id Integer 
 * hostRunRecipeParams HostRunRecipeParams 
 * returns Object
 **/
exports.runrecipe = function(id,hostRunRecipeParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * id Integer 
 * hostBillOptionImageGib HostBillOptionImageGib 
 * returns Object
 **/
exports.set_image_gib_limit = function(id,hostBillOptionImageGib) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer ID хоста
 * emptyParams EmptyParams Пустые параметры
 * returns Object
 **/
exports.start = function(host_id,emptyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * host_id Integer ID хоста
 * emptyParams EmptyParams Пустые параметры
 * returns Object
 **/
exports.stop = function(host_id,emptyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

