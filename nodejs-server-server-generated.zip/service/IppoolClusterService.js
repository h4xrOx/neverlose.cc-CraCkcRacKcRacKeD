'use strict';


/**
 * Подключение пула к кластерам
 *
 * ippool_id Integer 
 * ippoolClusterParams IppoolClusterParams Параметры подключения пула к кластерам
 * no response value expected for this operation
 **/
exports.cluster = function(ippool_id,ippoolClusterParams) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Список кластеров к котром подключен пул
 *
 * ippool_id Integer 
 * returns IppoolClusterList
 **/
exports.list = function(ippool_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

