'use strict';


/**
 * Создание образа ВМ
 *
 * host_id Integer ID ВМ из которой создаётся образ
 * hostImageParams HostImageParams Параметры создаваемого образа ВМ
 * cookie String Авторизация в куки ses6=XXXXXXX (optional)
 * returns Object
 **/
exports.add = function(host_id,hostImageParams,cookie) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Копирование образа ВМ
 *
 * image_id Integer ID образа ВМ
 * imageCopyParams ImageCopyParams Параметры для копирования образа
 * returns Object
 **/
exports.copy = function(image_id,imageCopyParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Удаление образа ВМ
 *
 * image_id Integer ID удаляемого образа ВМ
 * returns Object
 **/
exports.delete = function(image_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Редактирование образа ВМ
 *
 * image_id Integer ID редактируемого образа ВМ
 * imageChangeParams ImageChangeParams Параметры для редактирования образа
 * returns Object
 **/
exports.edit = function(image_id,imageChangeParams) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * image_id Integer 
 * returns Object
 **/
exports.get = function(image_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [
    123,
    125
  ],
  "empty": false
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Список образов ВМ
 *
 * cookie String Авторизация в куки ses6=XXXXXX (optional)
 * returns HostImageList
 **/
exports.list = function(cookie) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

