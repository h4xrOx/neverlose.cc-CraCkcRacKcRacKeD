'use strict';

var utils = require('../utils/writer.js');
var Recipe = require('../service/RecipeService');

module.exports.add = function add (req, res, next) {
  var recipeParams = req.swagger.params['RecipeParams'].value;
  Recipe.add(recipeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var recipe_id = req.swagger.params['recipe_id'].value;
  Recipe.delete(recipe_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var recipe_id = req.swagger.params['recipe_id'].value;
  var recipeUpdateParams = req.swagger.params['RecipeUpdateParams'].value;
  Recipe.edit(recipe_id,recipeUpdateParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var recipe_id = req.swagger.params['recipe_id'].value;
  Recipe.get(recipe_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  Recipe.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
