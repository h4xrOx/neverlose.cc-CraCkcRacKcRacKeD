'use strict';

var utils = require('../utils/writer.js');
var Repository = require('../service/RepositoryService');

module.exports.add = function add (req, res, next) {
  var repositoryParams = req.swagger.params['RepositoryParams'].value;
  Repository.add(repositoryParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var id = req.swagger.params['id'].value;
  Repository.delete(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var id = req.swagger.params['id'].value;
  Repository.get(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  Repository.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
