'use strict';

var utils = require('../utils/writer.js');
var UserLimits = require('../service/UserLimitsService');

module.exports.add_for_account = function add_for_account (req, res, next) {
  var account_name = req.swagger.params['account_name'].value;
  var user_limits_params = req.swagger.params['user_limits_params'].value;
  UserLimits.add_for_account(account_name,user_limits_params)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.add_for_role = function add_for_role (req, res, next) {
  var role_name = req.swagger.params['role_name'].value;
  var user_limits_params = req.swagger.params['user_limits_params'].value;
  UserLimits.add_for_role(role_name,user_limits_params)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete_for_account = function delete_for_account (req, res, next) {
  var account_name = req.swagger.params['account_name'].value;
  UserLimits.delete_for_account(account_name)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete_for_role = function delete_for_role (req, res, next) {
  var role_name = req.swagger.params['role_name'].value;
  UserLimits.delete_for_role(role_name)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  UserLimits.get()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_for_account = function get_for_account (req, res, next) {
  var account_name = req.swagger.params['account_name'].value;
  UserLimits.get_for_account(account_name)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_for_role = function get_for_role (req, res, next) {
  var role_name = req.swagger.params['role_name'].value;
  UserLimits.get_for_role(role_name)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
