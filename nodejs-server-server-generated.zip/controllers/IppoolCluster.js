'use strict';

var utils = require('../utils/writer.js');
var IppoolCluster = require('../service/IppoolClusterService');

module.exports.cluster = function cluster (req, res, next) {
  var ippool_id = req.swagger.params['ippool_id'].value;
  var ippoolClusterParams = req.swagger.params['IppoolClusterParams'].value;
  IppoolCluster.cluster(ippool_id,ippoolClusterParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  var ippool_id = req.swagger.params['ippool_id'].value;
  IppoolCluster.list(ippool_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
