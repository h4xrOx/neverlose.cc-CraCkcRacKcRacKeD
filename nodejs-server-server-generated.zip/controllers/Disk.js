'use strict';

var utils = require('../utils/writer.js');
var Disk = require('../service/DiskService');

module.exports.resize = function resize (req, res, next) {
  var id = req.swagger.params['id'].value;
  var diskResizeParams = req.swagger.params['DiskResizeParams'].value;
  Disk.resize(id,diskResizeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
