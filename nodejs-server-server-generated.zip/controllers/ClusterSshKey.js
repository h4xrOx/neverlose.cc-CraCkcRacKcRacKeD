'use strict';

var utils = require('../utils/writer.js');
var ClusterSshKey = require('../service/ClusterSshKeyService');

module.exports.ssh_key = function ssh_key (req, res, next) {
  var cluster_id = req.swagger.params['cluster_id'].value;
  var sshKeyClusterParams = req.swagger.params['SshKeyClusterParams'].value;
  ClusterSshKey.ssh_key(cluster_id,sshKeyClusterParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
