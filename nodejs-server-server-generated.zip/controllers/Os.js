'use strict';

var utils = require('../utils/writer.js');
var Os = require('../service/OsService');

module.exports.delete = function delete (req, res, next) {
  var id = req.swagger.params['id'].value;
  Os.delete(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var id = req.swagger.params['id'].value;
  var oSEditParams = req.swagger.params['OSEditParams'].value;
  Os.edit(id,oSEditParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  Os.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
