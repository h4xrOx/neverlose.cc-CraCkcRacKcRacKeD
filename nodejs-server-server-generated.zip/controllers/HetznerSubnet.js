'use strict';

var utils = require('../utils/writer.js');
var HetznerSubnet = require('../service/HetznerSubnetService');

module.exports.delete = function delete (req, res, next) {
  var hetzner_subnet_id = req.swagger.params['hetzner_subnet_id'].value;
  HetznerSubnet.delete(hetzner_subnet_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
