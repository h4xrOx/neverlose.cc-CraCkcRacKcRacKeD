'use strict';

var utils = require('../utils/writer.js');
var Ippool = require('../service/IppoolService');

module.exports.delete = function delete (req, res, next) {
  var id = req.swagger.params['id'].value;
  Ippool.delete(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  var orderby = req.swagger.params['orderby'].value;
  Ippool.list(orderby)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
