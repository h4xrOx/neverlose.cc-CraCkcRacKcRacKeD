'use strict';

var utils = require('../utils/writer.js');
var HostImage = require('../service/HostImageService');

module.exports.add = function add (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostImageParams = req.swagger.params['HostImageParams'].value;
  var cookie = req.swagger.params['Cookie'].value;
  HostImage.add(host_id,hostImageParams,cookie)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.copy = function copy (req, res, next) {
  var image_id = req.swagger.params['image_id'].value;
  var imageCopyParams = req.swagger.params['ImageCopyParams'].value;
  HostImage.copy(image_id,imageCopyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var image_id = req.swagger.params['image_id'].value;
  HostImage.delete(image_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var image_id = req.swagger.params['image_id'].value;
  var imageChangeParams = req.swagger.params['ImageChangeParams'].value;
  HostImage.edit(image_id,imageChangeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var image_id = req.swagger.params['image_id'].value;
  HostImage.get(image_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  var cookie = req.swagger.params['Cookie'].value;
  HostImage.list(cookie)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
