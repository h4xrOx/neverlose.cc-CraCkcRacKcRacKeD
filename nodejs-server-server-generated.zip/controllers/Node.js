'use strict';

var utils = require('../utils/writer.js');
var Node = require('../service/NodeService');

module.exports.add = function add (req, res, next) {
  var nodeParams = req.swagger.params['NodeParams'].value;
  Node.add(nodeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  Node.delete(node_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  var nodeUpdateParams = req.swagger.params['NodeUpdateParams'].value;
  Node.edit(node_id,nodeUpdateParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  Node.get(node_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  Node.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.run_script = function run_script (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  var node_run_script_params = req.swagger.params['node_run_script_params'].value;
  Node.run_script(node_id,node_run_script_params)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.update_certificates = function update_certificates (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  Node.update_certificates(node_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
