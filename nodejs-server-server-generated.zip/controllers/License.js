'use strict';

var utils = require('../utils/writer.js');
var License = require('../service/LicenseService');

module.exports.edit = function edit (req, res, next) {
  var licenseEditParams = req.swagger.params['LicenseEditParams'].value;
  License.edit(licenseEditParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  License.get()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
