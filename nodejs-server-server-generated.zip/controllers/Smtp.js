'use strict';

var utils = require('../utils/writer.js');
var Smtp = require('../service/SmtpService');

module.exports.settingsSmtpGET = function settingsSmtpGET (req, res, next) {
  Smtp.settingsSmtpGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.settingsSmtpPOST = function settingsSmtpPOST (req, res, next) {
  var smtpParams = req.swagger.params['SmtpParams'].value;
  Smtp.settingsSmtpPOST(smtpParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
