'use strict';

var utils = require('../utils/writer.js');
var User = require('../service/UserService');

module.exports.delete = function delete (req, res, next) {
  var id = req.swagger.params['id'].value;
  User.delete(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.invite = function invite (req, res, next) {
  var inviteParams = req.swagger.params['InviteParams'].value;
  User.invite(inviteParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.invite_1 = function invite_1 (req, res, next) {
  var id = req.swagger.params['id'].value;
  User.invite_1(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.invite_2 = function invite_2 (req, res, next) {
  var id = req.swagger.params['id'].value;
  User.invite_2(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
