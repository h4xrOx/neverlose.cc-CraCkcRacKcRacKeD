'use strict';

var utils = require('../utils/writer.js');
var HetznerNode = require('../service/HetznerNodeService');

module.exports.add_ip = function add_ip (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  var addHetznerIpParams = req.swagger.params['AddHetznerIpParams'].value;
  HetznerNode.add_ip(node_id,addHetznerIpParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ip_list = function ip_list (req, res, next) {
  var node_id = req.swagger.params['node_id'].value;
  HetznerNode.ip_list(node_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
