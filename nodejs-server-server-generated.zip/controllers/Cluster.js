'use strict';

var utils = require('../utils/writer.js');
var Cluster = require('../service/ClusterService');

module.exports.add = function add (req, res, next) {
  var clusterParams = req.swagger.params['ClusterParams'].value;
  var cookie = req.swagger.params['Cookie'].value;
  Cluster.add(clusterParams,cookie)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var id = req.swagger.params['id'].value;
  Cluster.delete(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var id = req.swagger.params['id'].value;
  var clusterEditParams = req.swagger.params['ClusterEditParams'].value;
  Cluster.edit(id,clusterEditParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var id = req.swagger.params['id'].value;
  Cluster.get(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ippool = function ippool (req, res, next) {
  var cluster_id = req.swagger.params['cluster_id'].value;
  var clusterIppoolParams = req.swagger.params['ClusterIppoolParams'].value;
  Cluster.ippool(cluster_id,clusterIppoolParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  var cookie = req.swagger.params['Cookie'].value;
  Cluster.list(cookie)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
