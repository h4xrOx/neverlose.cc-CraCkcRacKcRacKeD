'use strict';

var utils = require('../utils/writer.js');
var Host = require('../service/HostService');

module.exports.add = function add (req, res, next) {
  var hostParams = req.swagger.params['HostParams'].value;
  Host.add(hostParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.add_ip = function add_ip (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var addIpParams = req.swagger.params['AddIpParams'].value;
  Host.add_ip(host_id,addIpParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.change_account = function change_account (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostAccountParams = req.swagger.params['HostAccountParams'].value;
  Host.change_account(host_id,hostAccountParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.change_password = function change_password (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostChangePasswordParams = req.swagger.params['HostChangePasswordParams'].value;
  Host.change_password(host_id,hostChangePasswordParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.clone = function clone (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var emptyParams = req.swagger.params['EmptyParams'].value;
  Host.clone(host_id,emptyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  Host.delete(host_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete_ip = function delete_ip (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var ip_id = req.swagger.params['ip_id'].value;
  Host.delete_ip(host_id,ip_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostChangeParams = req.swagger.params['HostChangeParams'].value;
  Host.edit(host_id,hostChangeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit_resource = function edit_resource (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostResourceParams = req.swagger.params['HostResourceParams'].value;
  Host.edit_resource(host_id,hostResourceParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  Host.get(host_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_host_history = function get_host_history (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  Host.get_host_history(host_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ip_list = function ip_list (req, res, next) {
  Host.ip_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.iso_cancel = function iso_cancel (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var emptyParams = req.swagger.params['EmptyParams'].value;
  Host.iso_cancel(host_id,emptyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.iso_finish = function iso_finish (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var emptyParams = req.swagger.params['EmptyParams'].value;
  Host.iso_finish(host_id,emptyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.iso_mount = function iso_mount (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostIsoMountParams = req.swagger.params['HostIsoMountParams'].value;
  Host.iso_mount(host_id,hostIsoMountParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  Host.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.migrate = function migrate (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostMigrateParams = req.swagger.params['HostMigrateParams'].value;
  Host.migrate(host_id,hostMigrateParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reinstall = function reinstall (req, res, next) {
  var id = req.swagger.params['id'].value;
  var hostReinstallParams = req.swagger.params['HostReinstallParams'].value;
  Host.reinstall(id,hostReinstallParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.rescue_mode = function rescue_mode (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var hostRescueModeParams = req.swagger.params['HostRescueModeParams'].value;
  Host.rescue_mode(host_id,hostRescueModeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.restart = function restart (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var emptyParams = req.swagger.params['EmptyParams'].value;
  Host.restart(host_id,emptyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.runrecipe = function runrecipe (req, res, next) {
  var id = req.swagger.params['id'].value;
  var hostRunRecipeParams = req.swagger.params['HostRunRecipeParams'].value;
  Host.runrecipe(id,hostRunRecipeParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.set_image_gib_limit = function set_image_gib_limit (req, res, next) {
  var id = req.swagger.params['id'].value;
  var hostBillOptionImageGib = req.swagger.params['HostBillOptionImageGib'].value;
  Host.set_image_gib_limit(id,hostBillOptionImageGib)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.start = function start (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var emptyParams = req.swagger.params['EmptyParams'].value;
  Host.start(host_id,emptyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.stop = function stop (req, res, next) {
  var host_id = req.swagger.params['host_id'].value;
  var emptyParams = req.swagger.params['EmptyParams'].value;
  Host.stop(host_id,emptyParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
