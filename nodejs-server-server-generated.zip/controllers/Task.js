'use strict';

var utils = require('../utils/writer.js');
var Task = require('../service/TaskService');

module.exports.delete = function delete (req, res, next) {
  var task_id = req.swagger.params['task_id'].value;
  Task.delete(task_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  Task.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
