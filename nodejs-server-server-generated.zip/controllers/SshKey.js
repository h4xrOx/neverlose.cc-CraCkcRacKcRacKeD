'use strict';

var utils = require('../utils/writer.js');
var SshKey = require('../service/SshKeyService');

module.exports.add = function add (req, res, next) {
  var sshKeyCreateParams = req.swagger.params['SshKeyCreateParams'].value;
  SshKey.add(sshKeyCreateParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var ssh_key_id = req.swagger.params['ssh_key_id'].value;
  SshKey.delete(ssh_key_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  SshKey.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
