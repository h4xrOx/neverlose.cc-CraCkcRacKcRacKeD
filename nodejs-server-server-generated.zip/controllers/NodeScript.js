'use strict';

var utils = require('../utils/writer.js');
var NodeScript = require('../service/NodeScriptService');

module.exports.add = function add (req, res, next) {
  var nodeScriptCreateParams = req.swagger.params['NodeScriptCreateParams'].value;
  NodeScript.add(nodeScriptCreateParams)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.delete = function delete (req, res, next) {
  var node_script_id = req.swagger.params['node_script_id'].value;
  NodeScript.delete(node_script_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.edit = function edit (req, res, next) {
  var nodeScriptEditParams = req.swagger.params['NodeScriptEditParams'].value;
  var node_script_id = req.swagger.params['node_script_id'].value;
  NodeScript.edit(nodeScriptEditParams,node_script_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get = function get (req, res, next) {
  var node_script_id = req.swagger.params['node_script_id'].value;
  NodeScript.get(node_script_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.list = function list (req, res, next) {
  NodeScript.list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
