import AccountApi from './resources/AccountApi';
import ClusterApi from './resources/ClusterApi';
import ClusterSshKeyApi from './resources/ClusterSshKeyApi';
import DiskApi from './resources/DiskApi';
import HetznerIpApi from './resources/HetznerIpApi';
import HetznerNodeApi from './resources/HetznerNodeApi';
import HetznerSubnetApi from './resources/HetznerSubnetApi';
import HostApi from './resources/HostApi';
import HostImageApi from './resources/HostImageApi';
import IppoolApi from './resources/IppoolApi';
import IppoolClusterApi from './resources/IppoolClusterApi';
import LicenseApi from './resources/LicenseApi';
import NodeApi from './resources/NodeApi';
import NodeFilesApi from './resources/NodeFilesApi';
import NodeScriptApi from './resources/NodeScriptApi';
import OsApi from './resources/OsApi';
import PresetApi from './resources/PresetApi';
import RecipeApi from './resources/RecipeApi';
import RepositoryApi from './resources/RepositoryApi';
import SmtpApi from './resources/SmtpApi';
import SshKeyApi from './resources/SshKeyApi';
import TaskApi from './resources/TaskApi';
import UserApi from './resources/UserApi';
import UserLimitsApi from './resources/UserLimitsApi';

let moduleName = 'ISPsystem vm API'.toLowerCase().replace(/\s/g, '.');

export default angular
  .module(moduleName, [])
  .service('AccountApi', AccountApi)
    .service('ClusterApi', ClusterApi)
    .service('ClusterSshKeyApi', ClusterSshKeyApi)
    .service('DiskApi', DiskApi)
    .service('HetznerIpApi', HetznerIpApi)
    .service('HetznerNodeApi', HetznerNodeApi)
    .service('HetznerSubnetApi', HetznerSubnetApi)
    .service('HostApi', HostApi)
    .service('HostImageApi', HostImageApi)
    .service('IppoolApi', IppoolApi)
    .service('IppoolClusterApi', IppoolClusterApi)
    .service('LicenseApi', LicenseApi)
    .service('NodeApi', NodeApi)
    .service('NodeFilesApi', NodeFilesApi)
    .service('NodeScriptApi', NodeScriptApi)
    .service('OsApi', OsApi)
    .service('PresetApi', PresetApi)
    .service('RecipeApi', RecipeApi)
    .service('RepositoryApi', RepositoryApi)
    .service('SmtpApi', SmtpApi)
    .service('SshKeyApi', SshKeyApi)
    .service('TaskApi', TaskApi)
    .service('UserApi', UserApi)
    .service('UserLimitsApi', UserLimitsApi)
  ;

